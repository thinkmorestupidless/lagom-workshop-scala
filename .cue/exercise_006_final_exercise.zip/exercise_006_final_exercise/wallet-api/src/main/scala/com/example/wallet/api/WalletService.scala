package com.example.wallet.api

import akka.{Done, NotUsed}
import com.lightbend.lagom.scaladsl.api.broker.Topic
import com.lightbend.lagom.scaladsl.api.broker.kafka.{KafkaProperties, PartitionKeyStrategy}
import com.lightbend.lagom.scaladsl.api.{Service, ServiceCall}
import julienrf.json.derived
import play.api.libs.json._

object WalletService {

}

trait WalletService extends Service {

  def balance(walletId: String): ServiceCall[NotUsed, Wallet]

  def deposit(walletId: String): ServiceCall[DepositMessage, Done]

  def send(walletId: String): ServiceCall[SendCurrencyMessage, Done]

  def getWallet(walletId: String): ServiceCall[NotUsed, Wallet]

  def walletEvents: Topic[WalletEventPublish]

  override final def descriptor = {
    import Service._
    named("wallet")
      .withCalls(
        pathCall("/api/balance/:walletId", balance _),
        pathCall("/api/deposit/:receivingWalletId", deposit _),
        pathCall("/api/send/:receivingWalletId", send _),
        pathCall("/api/wallet/:walletId", getWallet _)
      ).withTopics(
      topic("wallet-walletEvents", walletEvents)
        .addProperty(
          KafkaProperties.partitionKeyStrategy,
          PartitionKeyStrategy[WalletEventPublish](_.walletId)
        )
    ).withAutoAcl(true)
  }
}

case class DepositMessage(currency: String, amount: BigDecimal)

object DepositMessage {
  implicit val format: Format[DepositMessage] = Json.format
}

case class SendCurrencyMessage(currency: String, amount: BigDecimal, receivingWalletId: String)

object SendCurrencyMessage {
  implicit val format: Format[SendCurrencyMessage] = Json.format
}

case class Currency(name: String, amount: BigDecimal)

object Currency {
  implicit val format: Format[Currency] = Json.format
}

case class Wallet(owner: String, balances: List[Currency])

object Wallet {
  implicit val format: Format[Wallet] = Json.format
}

sealed trait WalletEventPublish {
  val walletId: String
}

object WalletEventPublish {
  implicit val format: Format[WalletEventPublish] = Json.format
}

case class CurrencySent(walletId: String, receivingWalletId: String, currency: String, amount: BigDecimal) extends WalletEventPublish

object CurrencySent {
  implicit val format: Format[CurrencySent] = Json.format
}

case class CurrencyDeposited(walletId: String, currency: String, amount: BigDecimal) extends WalletEventPublish

object CurrencyDeposited {
  implicit val format: Format[CurrencyDeposited] = Json.format
}

case class NewWalletCreated(walletId: String, currency: String, amount: BigDecimal) extends WalletEventPublish

object NewWalletCreated {
  implicit val format: Format[NewWalletCreated] = Json.format
}