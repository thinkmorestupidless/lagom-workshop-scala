package com.example.magicmoneymint.api

import akka.{Done, NotUsed}
import com.lightbend.lagom.scaladsl.api.{Service, ServiceCall}
import play.api.libs.json.{Format, Json}

trait MagicMoneyMintService extends Service {

  def checkBalance(id: String): ServiceCall[NotUsed, String]

  def magicMoney(): ServiceCall[MintMessage, Done]

  override final def descriptor = {
    import Service._
    named("mint")
      .withCalls(
        pathCall("/api/check-balance/:id", checkBalance _),
        pathCall("/api/magic-money", magicMoney _)
      )
      .withAutoAcl(true)
  }
}

case class MintMessage(currency: String, amount: BigDecimal)

object MintMessage {
  implicit val format: Format[MintMessage] = Json.format
}
