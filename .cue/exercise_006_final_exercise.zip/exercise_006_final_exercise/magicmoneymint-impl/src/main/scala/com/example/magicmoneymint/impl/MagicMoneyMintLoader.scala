package com.example.magicmoneymint.impl

import cinnamon.lagom.CircuitBreakerInstrumentation
import com.example.magicmoneymint.api.MagicMoneyMintService
import com.example.wallet.api.WalletService
import com.lightbend.lagom.internal.spi.CircuitBreakerMetricsProvider
import com.lightbend.lagom.scaladsl.broker.kafka.LagomKafkaComponents
import com.lightbend.lagom.scaladsl.devmode.LagomDevModeComponents
import com.lightbend.lagom.scaladsl.persistence.cassandra.CassandraPersistenceComponents
import com.lightbend.lagom.scaladsl.server._
import com.lightbend.rp.servicediscovery.lagom.scaladsl.LagomServiceLocatorComponents
import com.softwaremill.macwire.wire
import play.api.libs.ws.ahc.AhcWSComponents

trait MagicMoneyMintComponents extends LagomServerComponents
  with CassandraPersistenceComponents {

  // Bind the service that this server provides
  override lazy val lagomServer = serverFor[MagicMoneyMintService](wire[MagicMoneyMintServiceImpl])

  // Register the JSON serializer registry
  override lazy val jsonSerializerRegistry = MagicMoneyMintSerializerRegistry

  persistentEntityRegistry.register(wire[MintEntity])
}

abstract class MagicMoneyMintApplication(context: LagomApplicationContext)
  extends LagomApplication(context)
    with MagicMoneyMintComponents
    with LagomKafkaComponents
    with AhcWSComponents {

  lazy val walletService = serviceClient.implement[WalletService]
  val walletStreamSubscriber = wire[WalletStreamSubscriber]
}

class MagicMoneyMintLoader extends LagomApplicationLoader {

  override def load(context: LagomApplicationContext): LagomApplication =
    new MagicMoneyMintApplication(context) with LagomServiceLocatorComponents

  override def loadDevMode(context: LagomApplicationContext): LagomApplication =
    new MagicMoneyMintApplication(context) with LagomDevModeComponents

  override def describeService = Some(readDescriptor[MagicMoneyMintService])
}
