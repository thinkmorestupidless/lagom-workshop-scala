package com.example.magicmoneymint.impl

import com.example.magicmoneymint.api.MagicMoneyMintService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

class MagicMoneyMintServiceImpl(registry: PersistentEntityRegistry) extends MagicMoneyMintService {

  override def checkBalance(id: String) = ServiceCall { _ =>
    val ref = registry.refFor[MintEntity](id)

    ref.ask(MintBalance(id))
  }

  override def magicMoney = ServiceCall { request =>
    val ref = registry.refFor[MintEntity](request.currency)

    ref.ask(MakeMoney(request.currency, request.amount))
  }
}
