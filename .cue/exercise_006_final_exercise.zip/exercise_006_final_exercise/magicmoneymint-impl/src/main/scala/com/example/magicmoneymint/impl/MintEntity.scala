package com.example.magicmoneymint.impl

import java.time.LocalDateTime

import akka.Done
import com.lightbend.lagom.scaladsl.persistence.PersistentEntity.ReplyType
import com.lightbend.lagom.scaladsl.persistence.{AggregateEvent, AggregateEventTag, PersistentEntity}
import play.api.libs.json.{Format, Json}

class MintEntity extends PersistentEntity {

  override type Command = MintCommand
  override type Event = MintEvent
  override type State = MintState

  override def initialState: MintState = MintState(0.0, "", LocalDateTime.now.toString)

  override def behavior: Behavior = {
    Actions().onCommand[MakeMoney, Done] {
      case (MakeMoney(currency, amount), ctx, state) =>
        ctx.thenPersist(MoneyMade(entityId, currency, amount)) { _ =>
          ctx.reply(Done)
        }
    }.onEvent {
      case (MoneyMade(_, _, amount), state) => MintState(state.totalValue + amount, entityId, LocalDateTime.now.toString)
    }.onReadOnlyCommand[MintBalance, String] {
      case (MintBalance(_), ctx, state) => ctx.reply(state.totalValue.toString)
    }
  }
}

case class MintState(totalValue: BigDecimal, currency: String, timestamp: String)

object MintState {
  implicit val format: Format[MintState] = Json.format
}

sealed trait MintEvent extends AggregateEvent[MintEvent] {
  def aggregateTag = MintEvent.Tag

  val id: String
}

object MintEvent {
  val Tag = AggregateEventTag.sharded[MintEvent](4)
}

case class MoneyMade(id: String, currency: String, amount: BigDecimal) extends MintEvent

object MoneyMade {
  implicit val format: Format[MoneyMade] = Json.format
}

sealed trait MintCommand

case class MintBalance(name: String) extends MintCommand with ReplyType[String]

object MintBalance {
  implicit val format: Format[MintBalance] = Json.format
}

case class MakeMoney(currency: String, amount: BigDecimal) extends MintCommand with ReplyType[Done]

object MakeMoney {
  implicit val format: Format[MakeMoney] = Json.format
}

case class TakeMoney(currency: String, amount: String) extends MintCommand with ReplyType[Done]

object TakeMoney {
  implicit val format: Format[TakeMoney] = Json.format
}




