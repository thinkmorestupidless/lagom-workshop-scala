package com.example.magicmoneymint.impl

import com.lightbend.lagom.scaladsl.playjson.{JsonSerializer, JsonSerializerRegistry}

import scala.collection.immutable.Seq

object MagicMoneyMintSerializerRegistry extends JsonSerializerRegistry {
  override def serializers: Seq[JsonSerializer[_]] = Seq(
    // State
    JsonSerializer[MintState],
    // Commands
    JsonSerializer[MintBalance],
    JsonSerializer[MakeMoney],
    JsonSerializer[TakeMoney],
    // Events
    JsonSerializer[MoneyMade]
  )
}
