package com.example.magicmoneymint.impl

import akka.Done
import akka.stream.scaladsl.Flow
import com.example.wallet.api.{CurrencySent, WalletEventPublish, WalletService}

import scala.concurrent.Future

class WalletStreamSubscriber(walletService: WalletService) {

  walletService.walletEvents.subscribe.atLeastOnce(Flow[WalletEventPublish].mapAsync(1) {
    case _ =>
      Future.successful(Done)
  })
}
