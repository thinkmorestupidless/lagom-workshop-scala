package com.example.wallet.impl

import akka.actor.ActorSystem
import akka.testkit.TestKit
import com.lightbend.lagom.scaladsl.playjson.JsonSerializerRegistry
import com.lightbend.lagom.scaladsl.testkit.PersistentEntityTestDriver
import org.scalatest.{BeforeAndAfterAll, Inside, Matchers, WordSpec}

class WalletEntitySpec extends WordSpec with Matchers with BeforeAndAfterAll with Inside {

  private val system = ActorSystem("AuctionEntitySpec",
    JsonSerializerRegistry.actorSystemSetupFor(WalletSerializerRegistry))

  private val walletId = "trevor"

  override protected def afterAll() = {
    TestKit.shutdownActorSystem(system)
  }

  private def withTestDriver(block: PersistentEntityTestDriver[WalletCommand, WalletEvent, WalletState] => Unit): Unit = {
    val driver = new PersistentEntityTestDriver(system, new WalletEntity, walletId)
    block(driver)
    if (driver.getAllIssues.nonEmpty) {
      driver.getAllIssues.foreach(println)
      fail("There were issues " + driver.getAllIssues.head)
    }
  }

  "The wallet entity" should {

    "allow checking a wallet's balance" in withTestDriver { driver =>

      val outcome = driver.run(CheckBalance(walletId))

      outcome.events should have length 0
      outcome.state.balances should have size 0
    }

    "allow money to be deposited" in withTestDriver { driver =>

      val outcome = driver.run(DepositCurrency("TrevCoin", 1000))

      outcome.events should contain only NewWalletCreated(walletId, "TrevCoin", 1000)
      //      outcome.state.balances.get("TrevCoin") should equal 1000
    }
  }
}
