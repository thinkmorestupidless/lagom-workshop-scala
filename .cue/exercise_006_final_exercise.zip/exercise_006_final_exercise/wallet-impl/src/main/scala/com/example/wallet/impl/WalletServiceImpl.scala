package com.example.wallet.impl

import akka.persistence.query.Offset
import com.example.wallet.api
import com.example.wallet.api.{WalletEventPublish, WalletService}
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.broker.TopicProducer
import com.lightbend.lagom.scaladsl.persistence.{EventStreamElement, PersistentEntityRegistry}

import scala.concurrent.Future

class WalletServiceImpl(persistentEntityRegistry: PersistentEntityRegistry, walletRepository: WalletRepository) extends WalletService {

  override def balance(walletId: String) = ServiceCall { _ =>
    val ref = persistentEntityRegistry.refFor[WalletEntity](walletId)

    ref.ask(CheckBalance(walletId))
  }

  override def deposit(walletId: String) = ServiceCall { request =>
    val ref = persistentEntityRegistry.refFor[WalletEntity](walletId)

    ref.ask(DepositCurrency(request.currency, request.amount))
  }

  override def send(walletId: String) = ServiceCall { request =>
    val ref = persistentEntityRegistry.refFor[WalletEntity](walletId)

    ref.ask(SendCurrency(request.currency, request.amount, request.receivingWalletId))
  }

  override def getWallet(walletId: String) = ServiceCall { _ =>
    walletRepository.getWallet(walletId)
  }

  override def walletEvents = TopicProducer.taggedStreamWithOffset(WalletEvent.Tag.allTags.toList) { (tag, offset) =>
    persistentEntityRegistry.eventStream(tag, offset)
      .mapAsync(1)(convertEvent)
  }

  def convertEvent(eventStreamElement: EventStreamElement[WalletEvent]): Future[(WalletEventPublish, Offset)] = {
    eventStreamElement.event match {
      case CurrencySent(sendingWalletId, receivingWalletId, currency, amount) =>
        val message = api.CurrencySent(sendingWalletId, receivingWalletId, currency, amount)
        Future.successful(message, eventStreamElement.offset)

      case NewWalletCreated(id, currency, amount) =>
        val message = api.NewWalletCreated(id, currency, amount)
        Future.successful(message, eventStreamElement.offset)

      case CurrencyDeposited(id, currency, amount) =>
        val message = api.CurrencyDeposited(id, currency, amount)
        Future.successful(message, eventStreamElement.offset)
    }
  }
}
