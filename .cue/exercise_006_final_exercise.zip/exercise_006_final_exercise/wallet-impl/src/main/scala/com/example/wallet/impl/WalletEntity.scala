package com.example.wallet.impl

import java.time.LocalDateTime

import akka.Done
import com.example.wallet.api
import com.lightbend.lagom.scaladsl.persistence.PersistentEntity.ReplyType
import com.lightbend.lagom.scaladsl.persistence.{AggregateEvent, AggregateEventTag, PersistentEntity}
import play.api.libs.json.{Format, Json}

class WalletEntity extends PersistentEntity {

  override type Command = WalletCommand
  override type Event = WalletEvent
  override type State = WalletState

  override def initialState: WalletState = WalletState(List.empty, LocalDateTime.now.toString)

  override def behavior: Behavior = {
    Actions().onCommand[DepositCurrency, Done] {
      case (DepositCurrency(currency, amount), ctx, state) =>
        if (state.balances.isEmpty) {
          ctx.thenPersist(NewWalletCreated(entityId, currency, amount)) { _ =>
            ctx.reply(Done)
          }
        } else {
          ctx.thenPersist(CurrencyDeposited(entityId, currency, amount)) { _ =>
            ctx.reply(Done)
          }
        }
    }.onCommand[SendCurrency, Done] {
      case (SendCurrency(currency, amount, receivingWalletId), ctx, state) =>
        ctx.thenPersist(CurrencySent(entityId, receivingWalletId, currency, amount)) { _ =>
          ctx.reply(Done)
        }
    }.onReadOnlyCommand[CheckBalance, api.Wallet] {
      case (CheckBalance(name), ctx, state) =>
        ctx.reply(api.Wallet(entityId, state.balances.map { c =>
          api.Currency(c.currency, c.amount)
        }))
    }.onEvent {
      case (NewWalletCreated(id, currency, amount), state) =>
        WalletState(List(Currency(currency, amount)), LocalDateTime.now.toString)

      case (CurrencyDeposited(id, currency, amount), state) =>

        val balance: Currency = state.balances.find(_.currency == currency).getOrElse(Currency(currency, 0))

        val otherBalances = state.balances.filter(x => x.currency != currency)
        val newBalances = otherBalances :+ Currency(currency, balance.amount + amount)

        WalletState(newBalances, LocalDateTime.now.toString)

      case (CurrencySent(id, receivingWalletId, currency, amount), state) =>

        val balance = state.balances.find(_.currency == currency).getOrElse(Currency(currency, 0))

        val otherBalances = state.balances.filter(x => x.currency != currency)
        val newBalances = otherBalances :+ Currency(currency, balance.amount - amount)

        WalletState(newBalances, LocalDateTime.now.toString)
    }
  }
}

case class Currency(currency: String, amount: BigDecimal)

object Currency {
  implicit val format: Format[Currency] = Json.format
}

case class WalletState(balances: List[Currency], timestamp: String)

object WalletState {
  implicit val format: Format[WalletState] = Json.format
}

sealed trait WalletEvent extends AggregateEvent[WalletEvent] {
  def aggregateTag = WalletEvent.Tag

  val id: String
}

object WalletEvent {
  val Tag = AggregateEventTag.sharded[WalletEvent](4)
}

case class CurrencyDeposited(id: String, currency: String, amount: BigDecimal) extends WalletEvent

object CurrencyDeposited {
  implicit val format: Format[CurrencyDeposited] = Json.format
}

case class NewWalletCreated(id: String, currency: String, amount: BigDecimal) extends WalletEvent

object NewWalletCreated {
  implicit val format: Format[NewWalletCreated] = Json.format
}

case class CurrencySent(id: String, receivingWalletId: String, currency: String, amount: BigDecimal) extends WalletEvent

object CurrencySent {
  implicit val format: Format[CurrencySent] = Json.format
}

sealed trait WalletCommand

case class CheckBalance(name: String) extends WalletCommand with ReplyType[api.Wallet]

object CheckBalance {
  implicit val format: Format[CheckBalance] = Json.format
}

case class DepositCurrency(currency: String, amount: BigDecimal) extends WalletCommand with ReplyType[Done]

object DepositCurrency {
  implicit val format: Format[DepositCurrency] = Json.format
}

case class SendCurrency(currency: String, amount: BigDecimal, receivingWalletId: String) extends WalletCommand with ReplyType[Done]

object SendCurrency {
  implicit val format: Format[SendCurrency] = Json.format
}

case class GetWallet(id: String) extends WalletCommand with ReplyType[String]

object GetWallet {
  implicit val format: Format[GetWallet] = Json.format
}