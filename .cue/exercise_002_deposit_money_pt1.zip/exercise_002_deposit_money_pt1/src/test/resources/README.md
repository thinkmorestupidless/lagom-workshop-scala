exercise_002_deposit_money_pt1

The next step is to deposit money - to write new data into the persistent entity.

TASK:

* Create a new Command for depositing money.

* Create 2 new events for creating a new wallet and depositing money into a wallet.

* Tell the WalletEntity how to handle the new Command.