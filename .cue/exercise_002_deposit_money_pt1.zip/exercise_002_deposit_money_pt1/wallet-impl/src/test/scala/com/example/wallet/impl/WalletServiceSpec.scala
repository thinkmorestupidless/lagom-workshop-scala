package com.example.wallet.impl

import com.example.wallet.api.{TransactionMessage, Wallet, WalletService}
import com.lightbend.lagom.scaladsl.server.LocalServiceLocator
import com.lightbend.lagom.scaladsl.testkit.ServiceTest
import org.scalatest.{AsyncWordSpec, BeforeAndAfterAll, Matchers}

class WalletServiceSpec extends AsyncWordSpec
  with Matchers
  with BeforeAndAfterAll {

  private val server = ServiceTest.startServer(
    ServiceTest.defaultSetup
      .withCassandra()
  ) { ctx =>
    new WalletApplication(ctx) with LocalServiceLocator
  }

  val client = server.serviceClient.implement[WalletService]

  override protected def afterAll() = server.stop()

  "wallet service" should {

    "return initial empty balance" in {
      balance("Alice").map { answer =>
        answer should equal (Wallet("Alice", List.empty))
      }
    }

    "deposit money into wallet" in {
      for {
        _ <- deposit("Alice", "TrevCoin", 10)
        wallet <- balance("Alice")
      } yield {
        wallet.owner should === ("Alice")
        wallet.balances should have length 1
      }
    }
  }

  def balance(walletId: String) = {
    client.balance("Alice").invoke()
  }

  def deposit(walletId: String, currency: String, amount: BigDecimal) = {
    val payload = TransactionMessage(currency, amount)
    client.deposit(walletId).invoke(payload)
  }
}
