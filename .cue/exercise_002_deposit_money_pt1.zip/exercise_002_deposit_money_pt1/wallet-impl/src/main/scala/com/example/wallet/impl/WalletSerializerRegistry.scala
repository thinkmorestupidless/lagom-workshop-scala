package com.example.wallet.impl

import com.example.wallet.api.Wallet
import com.lightbend.lagom.scaladsl.playjson.{JsonSerializer, JsonSerializerRegistry}

import scala.collection.immutable.Seq

object WalletSerializerRegistry extends JsonSerializerRegistry {
  override def serializers: Seq[JsonSerializer[_]] = Seq(
    // API
    JsonSerializer[Wallet],
    // State
    JsonSerializer[WalletState],
    // Commands
    JsonSerializer[CheckBalance],
    JsonSerializer[DepositCurrency],
    // Events
    JsonSerializer[CurrencyDeposited],
    JsonSerializer[NewWalletCreated]
  )
}
