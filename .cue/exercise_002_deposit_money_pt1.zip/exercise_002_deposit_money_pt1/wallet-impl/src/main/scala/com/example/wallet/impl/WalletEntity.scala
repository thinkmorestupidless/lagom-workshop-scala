package com.example.wallet.impl

import java.time.LocalDateTime

import akka.Done
import com.example.wallet.api
import com.lightbend.lagom.scaladsl.persistence.PersistentEntity.ReplyType
import com.lightbend.lagom.scaladsl.persistence.{AggregateEvent, AggregateEventTag, PersistentEntity}
import play.api.libs.json.{Format, Json}

class WalletEntity extends PersistentEntity {

  override type Command = WalletCommand
  override type Event = WalletEvent
  override type State = WalletState

  override def initialState: WalletState = WalletState(List.empty, LocalDateTime.now.toString)

  override def behavior: Behavior = {

    // TODO: Handle currency being deposited
    // HINT: handle the command, check if the balance is currently empty
    // if it is we want to persist a new Wallet, if not we just deposit
    // Don't forget to reply to the request (Done)

    Actions().onReadOnlyCommand[CheckBalance, api.Wallet] {
      case (CheckBalance(name), ctx, state) =>
        ctx.reply(api.Wallet(entityId, state.balances.map { c =>
          api.Currency(c.currency, c.amount)
        }))
    }.onEvent {
      case (NewWalletCreated(id, currency, amount), state) =>
        WalletState(List(Currency(currency, amount)), LocalDateTime.now.toString)

      case (CurrencyDeposited(id, currency, amount), state) =>

        val balance: Currency = state.balances.find(_.currency == currency).getOrElse(Currency(currency, 0))
        val newBalance: Currency = Currency(currency, balance.amount + amount)

        val otherBalances: List[Currency] = state.balances.filter(x => x.currency != currency)
        val newBalances = otherBalances :+ newBalance

        WalletState(newBalances, LocalDateTime.now.toString)
    }
  }
}

case class Currency(currency: String, amount: BigDecimal)

object Currency {
  implicit val format: Format[Currency] = Json.format
}

case class WalletState(balances: List[Currency], timestamp: String)

object WalletState {
  implicit val format: Format[WalletState] = Json.format
}

sealed trait WalletEvent extends AggregateEvent[WalletEvent] {
  def aggregateTag = WalletEvent.Tag

  val id: String
}

object WalletEvent {
  val Tag = AggregateEventTag.sharded[WalletEvent](4)
}

// TODO: Create a new WalletEvent which tells the
// world how much of which currency was deposited
// and which wallet it was deposited into

// TODO: Create a new WalletEvent which tells the
// world a new wallet was just created - also, how
// much of which currency was deposited
// and which wallet it was deposited into

sealed trait WalletCommand

case class CheckBalance(name: String) extends WalletCommand with ReplyType[api.Wallet]

object CheckBalance {
  implicit val format: Format[CheckBalance] = Json.format
}

// TODO: Create a new Command type which tells our
// entity how much of which currency we want to deposit
