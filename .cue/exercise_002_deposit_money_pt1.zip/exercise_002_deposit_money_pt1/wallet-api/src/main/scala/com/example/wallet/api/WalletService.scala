package com.example.wallet.api

import akka.{Done, NotUsed}
import com.lightbend.lagom.scaladsl.api.{Service, ServiceCall}
import play.api.libs.json.{Format, Json}

object WalletService {

}

trait WalletService extends Service {

  def balance(walletId: String): ServiceCall[NotUsed, Wallet]

  def deposit(walletId: String): ServiceCall[TransactionMessage, Done]

  override final def descriptor = {
    import Service._
    named("wallet")
      .withCalls(
        pathCall("/api/balance/:walletId", balance _),
        pathCall("/api/deposit/:receivingWalletId", deposit _)
    )
    .withAutoAcl(true)
  }
}

case class Currency(name: String, amount: BigDecimal)

object Currency {
  implicit val format: Format[Currency] = Json.format
}

case class Wallet(owner: String, balances: List[Currency])

object Wallet {
  implicit val format: Format[Wallet] = Json.format
}

case class TransactionMessage(currency: String, amount: BigDecimal)

object TransactionMessage {
  implicit val format: Format[TransactionMessage] = Json.format
}