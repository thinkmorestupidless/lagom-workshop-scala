exercise_005_produce_external_events

Here we're going to publish events from the Wallet service to the outside world via Kafka (or whatever messaging plane we're using).

TASK:

* Define a Topic in the WalletService descriptor.

* We'll need a handler function for that topic.

* We'll need to implement that handler in the service implementation.