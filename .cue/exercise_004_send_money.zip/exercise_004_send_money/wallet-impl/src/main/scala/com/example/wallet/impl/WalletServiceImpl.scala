package com.example.wallet.impl

import com.example.wallet.api.WalletService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

class WalletServiceImpl(persistentEntityRegistry: PersistentEntityRegistry, walletRepository: WalletRepository) extends WalletService {

  override def balance(walletId: String) = ServiceCall { _ =>
    val ref = persistentEntityRegistry.refFor[WalletEntity](walletId)

    ref.ask(CheckBalance(walletId))
  }

  override def deposit(walletId: String) = ServiceCall { request =>
    val ref = persistentEntityRegistry.refFor[WalletEntity](walletId)

    ref.ask(DepositCurrency(request.currency, request.amount))
  }

  override def getWallet(walletId: String) = ServiceCall { _ =>
    walletRepository.getWallet(walletId)
  }

  // TODO: implement the 'send' handler
}
