exercise_003_deposit_money_pt2

In this exercise we implement a CQRS read side using Lagom's ReadSide event processor APIs

TASK:

* The EventProcessor and the Repository have been set up for you - you just need to wire them up in the application loader and implement the service call