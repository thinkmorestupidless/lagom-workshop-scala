package com.example.wallet.impl

import java.util.concurrent.atomic.AtomicInteger

import akka.persistence.query.Sequence
import com.lightbend.lagom.scaladsl.api.ServiceLocator.NoServiceLocator
import com.lightbend.lagom.scaladsl.broker.kafka.LagomKafkaComponents
import com.lightbend.lagom.scaladsl.server.LagomApplication
import com.lightbend.lagom.scaladsl.testkit.{ReadSideTestDriver, ServiceTest}
import org.scalatest.{AsyncWordSpec, BeforeAndAfterAll, Matchers}
import play.api.libs.ws.ahc.AhcWSComponents

class WalletEventProcessorSpec extends AsyncWordSpec
  with BeforeAndAfterAll
  with Matchers {

  private val server = ServiceTest.startServer(ServiceTest.defaultSetup.withCassandra(true)) { ctx =>
    new LagomApplication(ctx) with WalletComponents with AhcWSComponents with LagomKafkaComponents {
      override def serviceLocator = NoServiceLocator
      override lazy val readSide: ReadSideTestDriver = new ReadSideTestDriver
    }
  }

  override def afterAll() = server.stop()

  private val testDriver = server.application.readSide
  private val itemRepository = server.application.walletRepository
  private val offset = new AtomicInteger()


  "The Wallet event processor" should {

    "create a wallet" in {

      for {
        _ <- feed("Alice", NewWalletCreated("Alice", "TrevCoin", 12))
        wallet <- getWallet("Alice")
      } yield {
        wallet.owner should === ("Alice")
        wallet.balances should have length 1
      }
    }
  }

  private def getWallet(walletId: String) = {
    itemRepository.getWallet(walletId)
  }

  private def feed(walletId: String, event: WalletEvent) = {
    testDriver.feed(walletId, event, Sequence(offset.getAndIncrement))
  }
}
