package com.example.wallet.impl

import com.example.wallet.api.{TransactionMessage, WalletService}
import com.lightbend.lagom.scaladsl.api.AdditionalConfiguration
import com.lightbend.lagom.scaladsl.server.{LagomApplication, LocalServiceLocator}
import com.lightbend.lagom.scaladsl.testkit.{ServiceTest, TestTopicComponents}
import org.scalatest.{AsyncWordSpec, BeforeAndAfterAll, Matchers}
import play.api.Configuration
import play.api.libs.ws.ahc.AhcWSComponents

import scala.concurrent.duration._
import scala.concurrent.{Future, Promise}

class WalletServiceIntegrationSpec extends AsyncWordSpec
  with Matchers
  with BeforeAndAfterAll {

  private val server = ServiceTest.startServer(ServiceTest.defaultSetup.withCassandra(true)) { ctx =>
    new LagomApplication(ctx) with WalletComponents with LocalServiceLocator with AhcWSComponents with TestTopicComponents {
      override def additionalConfiguration: AdditionalConfiguration =
        super.additionalConfiguration ++ Configuration.from(Map(
          "cassandra-query-journal.eventual-consistency-delay" -> "0"
        ))
    }
  }

  val walletService = server.serviceClient.implement[WalletService]

  override def afterAll = server.stop()

  "The Wallet service" should {

    "return a wallet for an owner" in {

      (for {
        _ <- deposit("Alice", "TrevCoin", 25)
      } yield {
        awaitSuccess() {
          for {
            wallet <- walletService.getWallet("Alice").invoke()
          } yield {
            wallet.balances should have length 1
          }
        }
      }).flatMap(identity)
    }
  }

  def deposit(walletId: String, currency: String, amount: BigDecimal) = {
    val payload = TransactionMessage(currency, amount)
    walletService.deposit(walletId).invoke(payload)
  }

  def awaitSuccess[T](maxDuration: FiniteDuration = 10.seconds, checkEvery: FiniteDuration = 100.milliseconds)(block: => Future[T]): Future[T] = {
    val checkUntil = System.currentTimeMillis() + maxDuration.toMillis

    def doCheck(): Future[T] = {
      block.recoverWith {
        case recheck if checkUntil > System.currentTimeMillis() =>
          val timeout = Promise[T]()
          server.application.actorSystem.scheduler.scheduleOnce(checkEvery) {
            timeout.completeWith(doCheck())
          }(server.executionContext)
          timeout.future
      }
    }

    doCheck()
  }
}
