package com.example.wallet.impl

import com.example.wallet.api

import scala.concurrent.{ExecutionContext, Future, Promise}
import com.datastax.driver.core._
import akka.Done
import com.lightbend.lagom.scaladsl.persistence.ReadSideProcessor
import com.lightbend.lagom.scaladsl.persistence.cassandra.{CassandraReadSide, CassandraSession}

private[impl] class WalletRepository(session: CassandraSession)(implicit ec: ExecutionContext) {

  def getWallet(id: String): Future[api.Wallet] = {
    session.selectAll(
      s"""
         SELECT
          *
         FROM
          ${WalletRepository.walletTable}
         WHERE
          ${WalletRepository.ownerField} = ?
       """, id).map { rows =>
      api.Wallet(
        id,
        rows.map(convertWalletRow).toList
      )
    }
  }

  private def convertWalletRow(row: Row) = {
    val currency = row.getString("currency")
    val balance = row.getDecimal(s"${WalletRepository.balanceField}")
    System.out.println(s"currency = $currency, balance = $balance")
    api.Currency(currency, balance)
  }
}

private[impl] class WalletEventProcessor(session: CassandraSession, readSide: CassandraReadSide)(implicit ec: ExecutionContext)
  extends ReadSideProcessor[WalletEvent] {

  private val insertCurrencyPromise = Promise[PreparedStatement]
  private val insertCurrency: Future[PreparedStatement] = insertCurrencyPromise.future

  def buildHandler() = {
    readSide.builder[WalletEvent](WalletRepository.walletEventOffset)
      .setGlobalPrepare(createTables)
      .setPrepare(_ => prepareStatements())
      .setEventHandler[NewWalletCreated](e => processCurrencyDeposited(e.entityId, e.event.currency, e.event.amount))
      .setEventHandler[CurrencyDeposited](e => processCurrencyDeposited(e.entityId, e.event.currency, e.event.amount))
      .build()
  }

  def aggregateTags = WalletEvent.Tag.allTags

  private def createTables() = {
    for {
      _ <- session.executeCreateTable(
        s"""
           CREATE TABLE IF NOT EXISTS ${WalletRepository.walletTable} (
             ${WalletRepository.ownerField} text,
             currency text,
             ${WalletRepository.balanceField} decimal,
             PRIMARY KEY (owner, currency)
           )
         """)
    } yield Done
  }

  private def prepareStatements() = {
    val insertCurrencyFuture = session.prepare(
      s"""
         INSERT INTO ${WalletRepository.walletTable} (
           ${WalletRepository.ownerField},
           currency,
           ${WalletRepository.balanceField}
         ) VALUES (?, ?, ?)
       """)
    insertCurrencyPromise.completeWith(insertCurrencyFuture)

    for {
      _ <- insertCurrencyFuture
    } yield Done
  }

  private def processCurrencyDeposited(id: String, currency: String, amount: BigDecimal) = {
    insertCurrency.map { ps =>
      val bindInsertCurrency = ps.bind()
      bindInsertCurrency.setString("owner", id)
      bindInsertCurrency.setString("currency", currency)
      bindInsertCurrency.setDecimal(s"${WalletRepository.balanceField}", amount.bigDecimal)
      List(bindInsertCurrency)
    }
  }
}

object WalletRepository {
  val walletEventOffset: String = "walletEventOffset"
  val walletTable: String = "wallets"
  val ownerField: String = "owner"
  val balanceField: String = "balance"
}
