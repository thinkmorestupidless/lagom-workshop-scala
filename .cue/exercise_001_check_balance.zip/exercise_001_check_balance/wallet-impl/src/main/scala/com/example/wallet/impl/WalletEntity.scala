package com.example.wallet.impl

import java.time.LocalDateTime

import com.example.wallet.api
import com.lightbend.lagom.scaladsl.persistence.PersistentEntity.ReplyType
import com.lightbend.lagom.scaladsl.persistence.{AggregateEvent, AggregateEventTag, PersistentEntity}
import play.api.libs.json.{Format, Json}

class WalletEntity extends PersistentEntity {

  override type Command = WalletCommand
  override type Event = WalletEvent
  override type State = WalletState

  override def initialState: WalletState = WalletState(List.empty, LocalDateTime.now.toString)

  override def behavior: Behavior = {
    Actions().onReadOnlyCommand[CheckBalance, api.Wallet] {
      case (CheckBalance(name), ctx, state) =>
        ctx.reply(api.Wallet(entityId, state.balances.map { c =>
          api.Currency(c.currency, c.amount)
        }))
    }
  }
}

case class Currency(currency: String, amount: BigDecimal)

object Currency {
  implicit val format: Format[Currency] = Json.format
}

case class WalletState(balances: List[Currency], timestamp: String)

object WalletState {
  implicit val format: Format[WalletState] = Json.format
}

sealed trait WalletEvent extends AggregateEvent[WalletEvent] {
  def aggregateTag = WalletEvent.Tag
}

object WalletEvent {
  val Tag = AggregateEventTag.sharded[WalletEvent](4)
}

sealed trait WalletCommand

case class CheckBalance(name: String) extends WalletCommand with ReplyType[api.Wallet]

object CheckBalance {
  implicit val format: Format[CheckBalance] = Json.format
}
