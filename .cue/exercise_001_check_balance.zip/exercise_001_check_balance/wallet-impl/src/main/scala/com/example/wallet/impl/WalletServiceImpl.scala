package com.example.wallet.impl

import com.example.wallet.api.WalletService
import com.lightbend.lagom.scaladsl.api.ServiceCall
import com.lightbend.lagom.scaladsl.persistence.PersistentEntityRegistry

class WalletServiceImpl(persistentEntityRegistry: PersistentEntityRegistry) extends WalletService {

  override def balance(walletId: String) = ServiceCall { _ =>
    // TODO: Retrieve the Wallet from the registry.
  }
}
