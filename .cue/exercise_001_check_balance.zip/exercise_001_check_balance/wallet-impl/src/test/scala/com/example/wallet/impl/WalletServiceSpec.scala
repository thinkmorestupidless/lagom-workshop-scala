package com.example.wallet.impl

import com.example.wallet.api.Wallet
import com.example.wallet.api.WalletService
import com.lightbend.lagom.scaladsl.server.LocalServiceLocator
import com.lightbend.lagom.scaladsl.testkit.ServiceTest
import org.scalatest.{AsyncWordSpec, BeforeAndAfterAll, Matchers}

class WalletServiceSpec extends AsyncWordSpec
  with Matchers
  with BeforeAndAfterAll {

  private val server = ServiceTest.startServer(
    ServiceTest.defaultSetup
      .withCassandra()
  ) { ctx =>
    new WalletApplication(ctx) with LocalServiceLocator
  }

  val client = server.serviceClient.implement[WalletService]

  override protected def afterAll() = server.stop()

  "wallet service" should {

    "return initial empty balance" in {
      client.balance("Alice").invoke().map { answer =>
        answer should equal (Wallet("Alice", List.empty))
      }
    }
  }
}
