exercise_001_check_balance

Here, we introduce Lagom Persistence.

A 'Wallet' contains balances for multiple currencies for a single ID.

Each Wallet exists as a PersistentEntity - backed by event sourcing the entity is resilient to failure of the node it's currently running upon.

TASK:

* Refactor the 'balance' method so it retrieves the appropriate Wallet from the persistent entity registry and returns it.